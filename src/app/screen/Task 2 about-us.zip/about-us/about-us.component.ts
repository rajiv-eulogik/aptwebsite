import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss']
})
export class AboutUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    var URL = "http://192.241.203.148:3010/api/Settings?filter={%22where%22:{%20%22type%22:%20%22aboutUs%22}}";
    this.makeAjaxCall(URL, "GET");
  }

  makeAjaxCall(url, methodType): void{
        var baseUrl = "http://192.241.203.148:3010";
        var xhr = new XMLHttpRequest();
        xhr.open(methodType, url, true);
        xhr.send();
        xhr.onreadystatechange = function(){
          if (xhr.readyState === 4){
              if (xhr.status === 200){
                console.log("xhr done successfully");
                var resp = xhr.responseText;
                var respJson = JSON.parse(resp);
                console.log( respJson.data[0]);
                var data = respJson.data[0]
                var aboutApt = data.aboutApt
                var aboutFounders = data.aboutFounders
                var aboutFaculties = data.aboutFaculties
                var aboutAptKeys = ["description"]
                var descriptionKeys = ["title", "description"]
                var generalkeys = ["about","designation","name"];
                var socialmediakeys = ["facebook","instagram","linkedin","twitter"];
                var image = ["image"];
                for(let i=0;i<aboutAptKeys.length;i++){
                  document.getElementById("aboutapt-"+aboutAptKeys[i]).innerHTML = aboutApt[aboutAptKeys[i]];
                }
                document.getElementById("aboutapt-coverImage").setAttribute("src", baseUrl + "/api/uploads/aboutUs/download/" + aboutApt["coverImage"]);
                for(let i=0;i<descriptionKeys.length;i++){
                  document.getElementById("aboutfounders-"+descriptionKeys[i]).innerHTML = aboutFounders[descriptionKeys[i]];
                  document.getElementById("aboutfaculties-"+descriptionKeys[i]).innerHTML = aboutFaculties[descriptionKeys[i]];
                }
                for(let i=0;i<generalkeys.length;i++){
                  for(let j=0;j<aboutFounders.founders.length;j++){
                    document.getElementById("founders" +j + "-"+generalkeys[i]).innerHTML = aboutFounders.founders[j][generalkeys[i]];
                  }
                }
                for(let i=0;i<aboutFounders.founders.length;i++){
                  document.getElementById("founderimage" + i).setAttribute("src", baseUrl + "/api/uploads/aboutUs/download/" + aboutFounders.founders[i]["image"]);
                }
                for(let i=0;i<aboutFaculties.faculties.length * 2;i++){
                  //since data is present only for 4, repetition is achieved so used modulus
                document.getElementById("facultyimage" + i).setAttribute("src", baseUrl + "/api/uploads/aboutUs/download/" + aboutFaculties.faculties[i%4]["image"]);
                }
                for(let i=0;i<generalkeys.length;i++){
                  for(let j=0;j<aboutFaculties.faculties.length * 2;j++){
                    //since data is present only for 4, repetition is achieved so used modulus
                    document.getElementById("faculties" +j + "-"+generalkeys[i]).innerHTML = aboutFaculties.faculties[j%4][generalkeys[i]];
                  }
                }
                for(let i=0;i<socialmediakeys.length;i++){
                  for(let j=0;j<aboutFounders.founders.length;j++){
                    document.getElementById("founders" +j + "-"+socialmediakeys[i]).setAttribute("href",  aboutFounders.founders[j][socialmediakeys[i]]);
                  } 
                  for(let j=0;j<aboutFaculties.faculties.length *2;j++){
                    //since data is present only for 4, repetition is achieved so used modulus
                    document.getElementById("faculties" +j + "-"+socialmediakeys[i]).setAttribute("href",  aboutFaculties.faculties[j%4][socialmediakeys[i]]);
                  }                 
                }
              } else {
                console.log("xhr failed");
              }
          } else {
              console.log("xhr processing going on");
          }
        }
        console.log("request sent succesfully");
      }
  }
